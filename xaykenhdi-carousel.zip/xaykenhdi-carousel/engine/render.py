"""Render một carousel @xaykenhdi_ từ posts/<slug>/post.json.

Cách chạy:
    python engine/render.py posts/12-co-nen-chay-quang-cao            # slide PNG + video bìa
    python engine/render.py posts/12-co-nen-chay-quang-cao --no-video # chỉ PNG
    python engine/render.py posts/12-co-nen-chay-quang-cao --only 1,3 # chỉ render slide 1 và 3

Kết quả: output/<slug>/slide-1.png … slide-N.png, cover.mp4, contact.jpg (ảnh ghép xem nhanh).
Định dạng post.json: xem engine/SCHEMA.md.
"""
import argparse, asyncio, html as H, json, pathlib, random, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
A = ROOT / "assets"
W, HT = 1080, 1350

VI = "U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB"
LA = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2190-2199,U+2212"


def uri(p):
    return pathlib.Path(p).resolve().as_uri()


def font_css():
    f = A / "fonts"
    css = []
    def ff(fam, pat, w, st="normal"):
        for sub, ur in (("vietnamese", VI), ("latin", LA)):
            css.append(f"@font-face{{font-family:'{fam}';font-weight:{w};font-style:{st};src:url('{uri(f / pat.format(s=sub))}') format('woff2');unicode-range:{ur}}}")
    ff("Anton", "anton-{s}-400-normal.woff2", 400)
    for w in (500, 600, 700):
        ff("Mont", "montserrat-{s}-%d-normal.woff2" % w, w)
    for w in (800, 900):
        ff("BVP", "be-vietnam-pro-{s}-%d-normal.woff2" % w, w)
    ff("PFD", "playfair-display-{s}-600-italic.woff2", 600, "italic")
    for name, w, st in (("regular", 400, "normal"), ("bold", 700, "normal"), ("italic", 400, "italic"), ("bolditalic", 700, "italic")):
        css.append(f"@font-face{{font-family:'Termes';font-weight:{w};font-style:{st};src:url('{uri(f / f'texgyretermes-{name}.otf')}')}}")
    return "\n".join(css)


PALETTES = json.loads((ROOT / "brand" / "palettes.json").read_text(encoding="utf-8"))


def palette(p):
    if isinstance(p, str):
        p = PALETTES[p]
    d = {"tag": "#22335c", "accent": "#ffd86b", "accent_ink": "#2a2205", "accent2": "#a9c7f0", "accent2_ink": "#13234a", "shade": "20,26,45"}
    d.update({k: v for k, v in p.items() if not k.startswith("_")})
    return d


# ------------------------------------------------------------------ inner slides
INNER_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{width:1080px;height:1350px;overflow:hidden;position:relative;background:#14110d;color:#fff;font-family:Termes}
.bg{position:absolute;inset:-20px;background-size:cover;filter:blur(3px) saturate(1) brightness(.8)}
.shade{position:absolute;inset:0;background:linear-gradient(180deg,rgba(30,26,14,.34) 0%,rgba(28,24,12,.3) 30%,rgba(26,20,10,.62) 100%)}
.tag{position:absolute;left:96px;top:96px;background:var(--tag);color:#fff;font-family:Mont;font-weight:500;font-size:36px;letter-spacing:-.02em;padding:14px 56px 16px;transform:rotate(1.2deg);z-index:3}
.head{position:absolute;right:86px;top:70px;text-align:center;z-index:3;line-height:.9;max-width:520px}
.solid{font-family:Anton;font-size:138px;color:#fff;text-shadow:0 4px 18px rgba(0,0,0,.35);white-space:nowrap}
.line{font-family:Anton;font-size:118px;color:transparent;-webkit-text-stroke:3.5px var(--accent);letter-spacing:.01em;white-space:nowrap}
.body{position:absolute;left:96px;right:96px;top:392px;bottom:70px;z-index:3;display:flex;flex-direction:column;justify-content:center}
#txt{font-size:34px;line-height:1.3;text-align:justify;text-shadow:0 2px 12px rgba(0,0,0,.6),0 0 2px rgba(0,0,0,.35)}
#txt p{margin-bottom:.42em}
#txt .h{font-family:Anton;font-weight:400;font-size:1.32em;letter-spacing:.01em;line-height:1.1;margin:.55em 0 .25em;text-align:left;color:var(--accent)}
#txt .h:first-child{margin-top:0}
#txt .h .n{color:transparent;-webkit-text-stroke:1.6px var(--accent);margin-right:.25em}
#txt i{font-style:italic}
#txt .ex{font-style:italic;text-align:left;border-left:4px solid var(--accent2);padding-left:.55em}
mark{background:var(--accent);color:var(--accent-ink);text-shadow:none;padding:0 .18em;box-decoration-break:clone;-webkit-box-decoration-break:clone}
.pg{position:absolute;right:96px;bottom:44px;font-family:Mont;font-weight:600;font-size:22px;letter-spacing:.08em;opacity:.75;z-index:3}
#txt ul{list-style:none;margin:0 0 .4em}
#txt li{text-align:left;padding-left:1em;text-indent:-1em;margin-bottom:.12em}
#txt li:before{content:"\\25CF";color:var(--accent);display:inline-block;width:1em;text-indent:0;font-size:.6em;vertical-align:.2em}
.tip{text-align:left;font-style:italic}
.tip .k{font-style:normal;font-family:Mont;font-weight:700;font-size:.6em;letter-spacing:.06em;background:var(--accent2);color:var(--accent2-ink);padding:.15em .5em;margin-right:.4em;vertical-align:.3em}
.cmp{display:grid;grid-template-columns:5.2em 1fr;gap:.25em .6em;margin:.15em 0 .5em;align-items:start;text-align:left}
.no,.yes{font-family:Mont;font-weight:700;font-size:.6em;letter-spacing:.05em;padding:.35em .4em;text-align:center}
.no{background:rgba(255,255,255,.18);color:#fff}
.yes{background:var(--accent);color:var(--accent-ink)}
.cmp .q1{opacity:.75;text-decoration:line-through;text-decoration-thickness:3px;text-decoration-color:#ff8a7a}
.lay{display:grid;grid-template-columns:2.2em 1fr;gap:.2em .5em;align-items:baseline;text-align:left;margin-bottom:.3em}
.lay .ic{font-family:Anton;background:var(--accent);color:var(--accent-ink);text-align:center;font-size:.85em;padding:.05em 0}
.chk{display:grid;grid-template-columns:1.3em 1fr;gap:.45em;text-align:left;margin-bottom:.28em;align-items:start}
.chk .bx{width:1em;height:1em;border:3px solid var(--accent);margin-top:.18em}
.step{display:grid;grid-template-columns:3.4em 1fr;gap:.55em;text-align:left;margin-bottom:.38em;align-items:start}
.step .b{font-family:Anton;background:var(--accent);color:var(--accent-ink);text-align:center;line-height:1.15;padding:.12em 0;font-size:.95em}
.calc{border:2.5px solid var(--accent);background:rgba(10,15,35,.4);padding:.45em .7em;margin:.2em 0 .5em;text-align:left}
.calc .r{display:grid;grid-template-columns:1fr auto;gap:.6em;border-bottom:1.5px dashed rgba(255,255,255,.3);padding:.15em 0}
.calc .r:last-child{border:0;font-family:Anton;color:var(--accent);font-size:1.1em;letter-spacing:.02em}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:.35em .7em;margin:.2em 0 .6em}
.chip{border:2px solid rgba(255,243,214,.7);padding:.35em .55em;background:rgba(0,0,0,.25);text-align:left;line-height:1.2}
.chip b{font-family:Anton;font-weight:400;font-size:1.25em;color:var(--accent);display:block;letter-spacing:.02em}
.chip small{font-family:Mont;font-weight:500;font-size:.7em;letter-spacing:.02em}
.week{display:grid;grid-template-columns:5.6em 1fr;gap:.6em;margin-bottom:.5em;align-items:start}
.week .w{font-family:Anton;color:var(--accent-ink);background:var(--accent);text-align:center;padding:.2em;line-height:1.1;font-size:.95em}
.week .w small{display:block;font-family:Mont;font-weight:600;font-size:.55em;letter-spacing:.02em}
.week .t{text-align:left}
.vs{display:grid;grid-template-columns:1fr 1fr;gap:.6em;margin:.3em 0 .6em}
.vs>div{border:2.5px solid rgba(255,255,255,.55);padding:.45em .6em;background:rgba(0,0,0,.28);text-align:left}
.vs .t{font-family:Anton;font-size:1.08em;letter-spacing:.02em;margin-bottom:.25em}
.vs li{font-size:.92em}
.sum{display:grid;grid-template-columns:1fr 1.25em 1.35fr;gap:.25em .4em;align-items:baseline;text-align:left;margin-bottom:.32em}
.sum .w{opacity:.75;text-decoration:line-through;text-decoration-color:var(--accent);text-decoration-thickness:3px}
.sum .a{font-family:Anton;color:var(--accent)}
.box{margin-top:.3em;border:2.5px solid var(--accent);padding:.55em .8em;background:rgba(15,20,40,.45)}
.box p{text-align:left!important;margin:0 0 .3em!important}
.kw{font-family:Anton;color:var(--accent)}
.kwb{font-family:Anton;background:var(--accent2);color:var(--accent2-ink);padding:0 .3em}
"""

FIT_JS = """(()=>{const b=document.querySelector('.body'),t=document.getElementById('txt');let s=34;
while(t.scrollHeight>b.clientHeight&&s>24){s-=.5;t.style.fontSize=s+'px'}
const hd=document.querySelector('.head');for(const el of hd.children){let f=parseFloat(getComputedStyle(el).fontSize);while(el.scrollWidth>520&&f>60){f-=2;el.style.fontSize=f+'px'}}
return {font:s,overflow:t.scrollHeight>b.clientHeight}})()"""


def block(b):
    """Một khối nội dung trong slide trong. Chuỗi được phép chứa <b>, <i>, <mark>."""
    (k, v), = b.items()
    if k == "p":
        return f"<p>{v}</p>"
    if k == "h":                      # ["01", "TIÊU ĐỀ"]
        return f'<div class="h"><span class="n">{v[0]}</span>{v[1]}</div>'
    if k == "h2":                     # tiêu đề nhỏ không số
        return f'<div class="h">{v}</div>'
    if k == "ul":
        return "<ul>" + "".join(f"<li>{x}</li>" for x in v) + "</ul>"
    if k == "ex":                     # ví dụ theo ngành, in nghiêng có vạch trái
        return "".join(f'<p class="ex">{x}</p>' for x in (v if isinstance(v, list) else [v]))
    if k == "mau":
        return f'<p style="text-align:left"><b>Mẫu:</b> <i>{v}</i></p>'
    if k == "tip":                    # ["NHÃN", "nội dung"]
        return f'<p class="tip"><span class="k">{v[0]}</span>{v[1]}</p>'
    if k == "cmp":                    # ["đừng…", "nên…"]
        return f'<div class="cmp"><span class="no">ĐỪNG</span><span class="q1">{v[0]}</span><span class="yes">NÊN</span><span>{v[1]}</span></div>'
    if k == "lay":                    # [["1","đậm","thường"], …]
        return "".join(f'<div class="lay"><span class="ic">{a}</span><span><b>{b_}</b> {c}</span></div>' for a, b_, c in v)
    if k == "chk":
        return "".join(f'<div class="chk"><span class="bx"></span><span>{x}</span></div>' for x in v)
    if k == "step":                   # [["1","đậm","thường"], …]
        return "".join(f'<div class="step"><span class="b">BƯỚC {a}</span><span><b>{b_}</b> {c}</span></div>' for a, b_, c in v)
    if k == "calc":                   # [["nhãn","giá trị"], …] dòng cuối là kết quả
        return '<div class="calc">' + "".join(f'<div class="r"><span>{a}</span><span>{c}</span></div>' for a, c in v) + "</div>"
    if k == "chips":                  # [["TIÊU ĐỀ","phụ"], …] lưới 2 cột
        return '<div class="grid">' + "".join(f'<div class="chip"><b>{a}</b><small>{c}</small></div>' for a, c in v) + "</div>"
    if k == "week":                   # [["4 TUẦN","5 ĐẾN 11/1","nội dung"], …]
        return "".join(f'<div class="week"><div class="w">{a}<small>{b_}</small></div><div class="t">{c}</div></div>' for a, b_, c in v)
    if k == "vs":                     # [{"t":"…","ul":[…]}, {…}]
        return '<div class="vs">' + "".join(f'<div><div class="t">{x["t"]}</div><ul>' + "".join(f"<li>{y}</li>" for y in x["ul"]) + "</ul></div>" for x in v) + "</div>"
    if k == "sum":                    # [["sai","đúng"], …]
        return "".join(f'<div class="sum"><span class="w">{a}</span><span class="a">→</span><span>{c}</span></div>' for a, c in v)
    if k == "cta":                    # {"save":"…","keyword":"KÊNH","promise":"…"}
        return (f'<div class="box"><p><b>Lưu bài này</b> {v["save"]}</p>'
                f'<p style="font-size:1.1em"><span class="kw">COMMENT</span> <span class="kwb">{v["keyword"]}</span> {v["promise"]}</p></div>')
    if k == "html":
        return v
    raise ValueError(f"Khối không hỗ trợ: {k}")


def inner_html(post, s, k, total, pal, fonts):
    bg = A / "backgrounds" / s["bg"]
    flip = "transform:scaleX(-1);" if s.get("flip") else ""
    body = "".join(block(b) for b in s["blocks"])
    var = f"--tag:{pal['tag']};--accent:{pal['accent']};--accent-ink:{pal['accent_ink']};--accent2:{pal['accent2']};--accent2-ink:{pal['accent2_ink']}"
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{fonts}{INNER_CSS}:root{{{var}}}</style></head><body>
<div class="bg" style="background-image:url('{uri(bg)}');background-position:{s.get('pos', '50% 50%')};{flip}"></div><div class="shade"></div>
<div class="tag">{H.escape(post.get('handle', 'xaykenhdi_'))}</div>
<div class="head"><div class="solid">{s['solid']}</div><div class="line">{s['line']}</div></div>
<div class="body"><div id="txt">{body}</div></div>
<div class="pg">{k:02d} / {total:02d}</div></body></html>"""


# ------------------------------------------------------------------ cover
COVER_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{width:1080px;height:1350px;overflow:hidden;position:relative;background:#2a3020}
.abs{position:absolute}
.big{font-family:BVP;font-weight:900;color:#fff;letter-spacing:-.045em;line-height:.9;white-space:nowrap;text-shadow:0 4px 22px rgba(0,0,0,.35),0 1px 3px rgba(0,0,0,.3)}
.accent{color:var(--accent);-webkit-text-stroke:3px #fff;paint-order:stroke fill}
.scr{font-family:PFD;font-style:italic;font-weight:600;white-space:nowrap;color:#fff;text-shadow:0 4px 22px rgba(0,0,0,.35),0 1px 3px rgba(0,0,0,.3)}
.pill{background:var(--tag);color:#fff8e6;font-family:BVP;font-weight:900;letter-spacing:-.03em;padding:12px 30px 18px;border-radius:20px;box-shadow:0 10px 24px rgba(0,0,0,.3);line-height:1.05}
.pill .a{color:var(--accent)} .pill .b{color:var(--accent2)}
.handle{background:#1f8bff;color:#fff;font-family:BVP;font-weight:800;font-size:34px;padding:12px 26px 14px;border-radius:40px;display:inline-flex;align-items:center;gap:14px;box-shadow:0 6px 18px rgba(0,0,0,.2)}
.handle.black{background:#111;border-radius:0;font-family:Mont;font-weight:500;font-size:40px;padding:14px 44px}
.stk-img{display:block;filter:drop-shadow(0 8px 12px rgba(0,0,0,.35))}
"""

HEART = '<svg width="34" height="34" viewBox="0 0 40 40"><rect x="1" y="1" width="38" height="38" rx="9" fill="#ffc94a"/><path d="M20 31 C8 23 7 15 12 12 C16 9.5 19 12 20 14 C21 12 24 9.5 28 12 C33 15 32 23 20 31Z" fill="#fff"/></svg>'

COVER_JS = """
const leftAt=(a,b)=>{let m=1e4;for(let y=Math.max(0,Math.floor(a));y<Math.min(1350,b);y++)m=Math.min(m,PROF[y]);return m};
// xếp các dòng tiêu đề thành 1 khối liền: mỗi dòng cách dòng trên đúng data-g px
const stack=()=>{let y=null;document.querySelectorAll('.stk').forEach(e=>{if(y===null){y=e.getBoundingClientRect().bottom;return}
 const r=e.getBoundingClientRect();const dy=(y+(+e.dataset.g))-r.top;e.style.top=(parseFloat(e.style.top)+dy)+'px';y=e.getBoundingClientRect().bottom})};
// dòng .tuck nằm sau người: thu nhỏ chữ đến khi mép phải chỉ lấn tối đa 30px vào người (che 1 góc nhỏ chữ cuối, không che mặt)
const tuck=()=>document.querySelectorAll('.tuck').forEach(e=>{let f=parseFloat(e.style.fontSize);for(;f>60;f-=2){e.style.fontSize=f+'px';
 const r=e.getBoundingClientRect();const lim=leftAt(r.top+r.height*.15,r.bottom-r.height*.15)+30;if(r.right<=lim)break}});
// dòng thường không được chạm vào người
const fit=()=>document.querySelectorAll('.stk:not(.tuck)').forEach(e=>{let f=parseFloat(e.style.fontSize||0);if(!f)return;for(;f>40;f-=2){
 const r=e.getBoundingClientRect();if(+e.style.zIndex>4||r.right<=leftAt(r.top,r.bottom)-12)break;e.style.fontSize=f+'px'}});
document.fonts.ready.then(()=>{stack();tuck();fit();stack();window.__ready=true});
"""


def person_profile(path, height, px, py):
    """Mép trái của người (theo từng dòng y) để biết chữ được phép chạy tới đâu."""
    from PIL import Image
    import numpy as np
    im = Image.open(path)
    w = round(im.width * height / im.height)
    a = np.array(im.convert("RGBA").resize((w, height)).split()[3]) > 100
    prof = [10000] * HT
    for y in range(height):
        xs = np.where(a[y])[0]
        if len(xs) and 0 <= py + y < HT:
            prof[py + y] = int(px + xs[0])
    return w, prof


def cover_html(post, pal, fonts):
    c = post["cover"]
    bg = A / "backgrounds" / c["background"]
    person = A / "people" / c["person"]
    ph = c.get("person_height", 860)
    from PIL import Image
    im = Image.open(person)
    pw = round(im.width * ph / im.height)
    px = c.get("person_x", W - pw - 70)
    py = c.get("person_y", HT - ph - 40)
    pw, prof = person_profile(person, ph, px, py)
    sh = pal["shade"]
    parts = []
    top = c.get("title_top", 380)
    left = c.get("title_left", 52)
    for i, ln in enumerate(c["lines"]):
        st = ln.get("style", "big")
        z = 2 if ln.get("tuck") else 6
        g = ln.get("gap", 0)
        rot = f"transform:rotate({ln['rotate']}deg);" if "rotate" in ln else ""
        lx = left + ln.get("dx", 0)
        cls = {"big": "big", "accent": "big accent", "script": "scr", "pill": "pill"}[st]
        cls += " stk" + (" tuck" if ln.get("tuck") else "")
        size = ln.get("size", {"big": 132, "accent": 240, "script": 104, "pill": 58}[st])
        parts.append(f'<div class="abs {cls}" data-g="{g}" style="left:{lx}px;top:{top}px;font-size:{size}px;z-index:{z};{rot}">{ln["text"]}</div>')
    stickers = "".join(
        f'<div class="abs a-st" style="left:{s["x"]}px;top:{s["y"]}px;z-index:7"><img class="stk-img" src="{uri(A / "stickers" / (s["name"] + ".png"))}" style="width:{s["w"]}px;transform:rotate({s.get("rot", 0)}deg)"></div>'
        for s in c.get("stickers", []))
    hcls = "handle black" if c.get("handle_style") == "black" else "handle"
    heart = "" if c.get("handle_style") == "black" else " " + HEART
    var = f"--tag:{pal['tag']};--accent:{pal['accent']};--accent2:{pal['accent2']}"
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{fonts}{COVER_CSS}:root{{{var}}}
body{{background:#2a3020 url('{uri(bg)}') {c.get('background_pos', 'center')}/cover}}</style></head><body>
<div class="abs" style="inset:0;background:linear-gradient(90deg,rgba({sh},.55) 0%,rgba({sh},.3) 55%,rgba({sh},.1) 100%),linear-gradient(180deg,rgba({sh},.25),transparent 40%,rgba({sh},.35))"></div>
{''.join(parts)}
<img class="abs" src="{uri(person)}" style="left:{px}px;top:{py}px;height:{ph}px;z-index:4;filter:drop-shadow(0 12px 18px rgba(0,0,0,.35))">
<div class="abs" style="left:50px;top:66px;z-index:8"><div class="{hcls}">{H.escape(post.get('handle', 'xaykenhdi_'))}{heart}</div></div>
{stickers}
<script>const PROF={json.dumps(prof)};{COVER_JS}</script>
</body></html>"""


ANIM_CSS = """
@keyframes bob{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-14px) rotate(4deg)}}
@keyframes wig{0%,100%{transform:rotate(-7deg)}50%{transform:rotate(7deg)}}
@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}
@keyframes drift{0%,100%{transform:translate(0,0) rotate(0)}25%{transform:translate(6px,-8px) rotate(5deg)}75%{transform:translate(-6px,6px) rotate(-5deg)}}
@keyframes tw{0%,100%{opacity:.15;transform:scale(.5) rotate(0)}50%{opacity:1;transform:scale(1.15) rotate(45deg)}}
.a-bob{animation:bob 2.5s ease-in-out infinite}.a-wig{animation:wig 1.25s ease-in-out infinite;transform-origin:50% 60%}
.a-pulse{animation:pulse 1.25s ease-in-out infinite}.a-drift{animation:drift 5s ease-in-out infinite}
.tw{position:absolute;z-index:7;animation:tw 1.25s ease-in-out infinite}
"""


def animate(cover):
    """Biến bìa tĩnh thành bìa động: sticker nhún/lắc, thêm lấp lánh. Mọi chu kỳ chia hết 5 giây để video lặp mượt."""
    kinds = ["a-bob", "a-wig", "a-pulse", "a-drift"]
    out, i = [], 0
    for chunk in cover.split('<div class="abs a-st"'):
        if out:
            chunk = f'<div class="abs a-st"' + chunk.replace('<img class="stk-img"', f'<div class="{kinds[i % 4]}"><img class="stk-img"', 1).replace('"></div>', '"></div></div>', 1)
            i += 1
        out.append(chunk)
    html = "".join(out).replace("</style>", ANIM_CSS + "</style>", 1)
    random.seed(4)
    cols = ["#cdfe84", "#f2a0d6", "#ffffff", "#e2d4fb", "#fffd60", "#d4eafb"]
    spots = [(560, 90), (990, 170), (30, 420), (380, 880), (700, 1290), (1010, 600), (1010, 1000), (320, 1300), (620, 920), (40, 940), (560, 1260), (700, 380)]
    tw = ""
    for j, (x, y) in enumerate(spots):
        s = random.randint(26, 44)
        tw += (f'<svg class="tw" style="left:{x}px;top:{y}px;animation-delay:{-(j * .21) % 1.25:.2f}s" width="{s}" height="{s}" viewBox="0 0 40 40">'
               f'<path d="M20 2 Q22.5 17.5 38 20 Q22.5 22.5 20 38 Q17.5 22.5 2 20 Q17.5 17.5 20 2Z" fill="{cols[j % 6]}" stroke="#503c36" stroke-width="1.6" stroke-linejoin="round"/></svg>')
    return html.replace("</body>", tw + "</body>")


async def render(post_dir, video=True, only=None):
    from playwright.async_api import async_playwright
    post = json.loads((post_dir / "post.json").read_text(encoding="utf-8"))
    slug = post.get("slug", post_dir.name)
    out = ROOT / "output" / slug
    out.mkdir(parents=True, exist_ok=True)
    pal = palette(post.get("palette", "navy-butter"))
    fonts = font_css()
    total = 1 + len(post["slides"])
    pages = {1: cover_html(post, pal, fonts)}
    for k, s in enumerate(post["slides"], start=2):
        pages[k] = inner_html(post, s, k, total, pal, fonts)
    report = []
    async with async_playwright() as p:
        br = await p.chromium.launch()
        pg = await br.new_page(viewport={"width": W, "height": HT})
        for k, html in pages.items():
            if only and k not in only:
                continue
            f = out / f"slide-{k}.html"
            f.write_text(html, encoding="utf-8")
            await pg.goto(f.as_uri())
            if k == 1:
                await pg.wait_for_function("window.__ready===true", timeout=15000)
            else:
                await pg.evaluate("document.fonts.ready")
                r = await pg.evaluate(FIT_JS)
                report.append((k, r))
            await pg.wait_for_timeout(150)
            await pg.screenshot(path=str(out / f"slide-{k}.png"))
        if video and (not only or 1 in only):
            fr = out / "_frames"
            shutil.rmtree(fr, ignore_errors=True)
            fr.mkdir()
            # dùng lại bố cục đã xếp sẵn của bìa tĩnh, rồi gắn animation
            settled = await pg.goto((out / "slide-1.html").as_uri())
            await pg.wait_for_function("window.__ready===true", timeout=15000)
            frozen = await pg.evaluate("document.documentElement.outerHTML")
            frozen = frozen.replace("document.fonts.ready.then(()=>{stack();tuck();fit();stack();window.__ready=true});", "window.__ready=true;")
            af = out / "slide-1-anim.html"
            af.write_text("<!doctype html>" + animate(frozen), encoding="utf-8")
            await pg.goto(af.as_uri())
            await pg.evaluate("document.fonts.ready")
            await pg.wait_for_timeout(300)
            fps, sec = 30, 5
            for i in range(fps * sec):
                await pg.evaluate(f"document.getAnimations().forEach(a=>{{a.pause();a.currentTime={i * 1000 / fps}}})")
                await pg.screenshot(path=str(fr / f"{i:04d}.png"))
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(fps), "-i", str(fr / "%04d.png"), "-c:v", "libx264",
                            "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out / "cover.mp4")], check=True)
            shutil.rmtree(fr)
        await br.close()
    # ảnh ghép để xem nhanh cả bài
    from PIL import Image
    pngs = sorted(out.glob("slide-*.png"), key=lambda p: int(p.stem.split("-")[1]))
    if pngs:
        tw_, th = 270, 338
        cols = 4
        rows = (len(pngs) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * tw_ + (cols + 1) * 10, rows * th + (rows + 1) * 10), "#ffffff")
        for i, pth in enumerate(pngs):
            im = Image.open(pth).convert("RGB").resize((tw_, th))
            sheet.paste(im, (10 + (i % cols) * (tw_ + 10), 10 + (i // cols) * (th + 10)))
        sheet.save(out / "contact.jpg", quality=85)
    for k, r in report:
        flag = "  ← CHỮ TRÀN, cần cắt bớt nội dung" if r["overflow"] else ("  ← chữ đã thu nhỏ, nên cắt bớt" if r["font"] < 28 else "")
        print(f"slide {k}: cỡ chữ {r['font']}px{flag}")
    print(f"Xong: {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("post_dir")
    ap.add_argument("--no-video", action="store_true")
    ap.add_argument("--only", help="ví dụ 1,3")
    a = ap.parse_args()
    only = {int(x) for x in a.only.split(",")} if a.only else None
    asyncio.run(render(pathlib.Path(a.post_dir).resolve(), video=not a.no_video, only=only))
