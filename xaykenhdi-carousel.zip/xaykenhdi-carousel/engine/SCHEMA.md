# Định dạng `posts/<slug>/post.json`

File mẫu đầy đủ: `posts/12-co-nen-chay-quang-cao/post.json`.

```json
{
  "slug": "13-ten-bai-khong-dau",          // tên thư mục output
  "title": "Tiêu đề bài (để lưu trữ)",
  "format": "hoi-dap-nen-chua",            // dạng nội dung, xem brand/content-formats.md
  "palette": "navy-pink",                  // tên trong brand/palettes.json, hoặc object màu
  "handle": "xaykenhdi_",                  // tuỳ chọn
  "cta": {"keyword": "KÊNH", "lead_magnet": ["1-bo-tai-lieu-xay-kenh"]},
  "cover": { … },
  "slides": [ … ]                          // slide 2 trở đi
}
```

## `cover` (slide 1)

| Trường | Ý nghĩa | Mặc định |
| --- | --- | --- |
| `background` | file trong `assets/backgrounds/` | bắt buộc |
| `background_pos` | vị trí ảnh nền (CSS) | `center` |
| `person` | file trong `assets/people/` | bắt buộc |
| `person_height` | chiều cao người, px. Giữ 800 đến 880 (60 đến 65% khung) | 860 |
| `person_x`, `person_y` | vị trí góc trên trái của người | sát phải, cách đáy 40px |
| `title_left`, `title_top` | vị trí dòng tiêu đề đầu | 52, 380 |
| `handle_style` | `"blue"` (pill xanh có tim) hoặc `"black"` | blue |
| `lines` | các dòng tiêu đề, từ trên xuống | bắt buộc |
| `stickers` | sticker 3D | `[]` |

Mỗi dòng trong `lines`:

| Trường | Ý nghĩa |
| --- | --- |
| `text` | nội dung, được dùng `<br>`, `<span class="a">` (màu nhấn), `<span class="b">` (màu phụ, chỉ trong pill) |
| `style` | `big` chữ đậm trắng · `accent` chữ đậm màu nhấn viền trắng · `script` chữ nghiêng · `pill` khung màu |
| `size` | cỡ chữ px (big ~130, accent ~240, script ~100, pill ~58) |
| `tuck` | `true` = dòng nằm SAU người, engine tự thu nhỏ để người chỉ che 1 góc nhỏ chữ cuối. Mỗi bìa 1 dòng tuck, thường là dòng chữ to nhất |
| `gap` | khoảng cách (px) so với đáy dòng trên. Âm = chồng lên nhau một chút. Engine tự xếp, nên các dòng luôn liền khối |
| `dx` | lệch trái/phải so với `title_left` |
| `rotate` | xoay (độ), nhẹ thôi: -5 đến 5 |

Mỗi sticker: `{"name": "camera", "x": 36, "y": 1120, "w": 190, "rot": -6}`. `name` là tên file trong `assets/stickers/` (không có .png). Xem `assets/stickers/_preview.jpg`.

## `slides` (slide 2 trở đi)

```json
{"bg": "bg_cafe_mid.jpg", "pos": "50% 40%", "flip": false,
 "solid": "DÒNG ĐẶC", "line": "DÒNG VIỀN",
 "blocks": [ {"p": "…"}, {"h": ["01", "TIÊU ĐỀ MỤC"]}, … ]}
```

`solid` + `line` là tiêu đề 2 dòng góc trên phải (IN HOA, mỗi dòng ≤ 14 ký tự để không bị thu nhỏ). `flip` lật ngang ảnh nền để đỡ lặp.

Các khối trong `blocks` (chuỗi được dùng `<b>`, `<i>`, `<mark>`):

| Khối | Dạng dữ liệu | Hiển thị |
| --- | --- | --- |
| `p` | chuỗi | đoạn văn |
| `h` | `["01", "TIÊU ĐỀ"]` | tiêu đề mục có số viền |
| `h2` | chuỗi | tiêu đề mục không số |
| `ul` | `["…", "…"]` | danh sách chấm tròn |
| `ex` | chuỗi hoặc danh sách | ví dụ theo ngành, nghiêng, vạch màu bên trái |
| `mau` | chuỗi | "Mẫu: …" nghiêng |
| `tip` | `["NHÃN", "nội dung"]` | nhãn màu + câu nghiêng (LỜI KHUYÊN, BÀI TẬP, QUY TẮC VÀNG…) |
| `cmp` | `["đừng…", "nên…"]` | so sánh ĐỪNG (gạch) / NÊN |
| `lay` | `[["1","đậm","thường"], …]` | danh sách có ô số màu |
| `step` | `[["1","đậm","thường"], …]` | BƯỚC 1, BƯỚC 2… |
| `chk` | `["…", …]` | checklist ô vuông |
| `calc` | `[["nhãn","giá trị"], …]` | khung tính toán, dòng cuối là kết quả |
| `chips` | `[["TIÊU ĐỀ","phụ"], …]` | lưới 2 cột |
| `week` | `[["4 TUẦN","5 ĐẾN 11/1","nội dung"], …]` | lịch theo mốc |
| `vs` | `[{"t":"…","ul":[…]}, {…}]` | 2 cột so sánh |
| `sum` | `[["sai","đúng"], …]` | bảng tóm lại sai → đúng |
| `cta` | `{"save":"…","keyword":"KÊNH","promise":"…"}` | khung Lưu bài này + COMMENT |
| `html` | chuỗi HTML | thoát hiểm khi cần bố cục riêng |

## Lượng chữ

Mỗi slide vừa khung ở cỡ 34px là đẹp nhất. Khi render, engine in cỡ chữ từng slide: dưới 28px là nhiều chữ quá, cắt bớt. "CHỮ TRÀN" là bắt buộc phải sửa.
