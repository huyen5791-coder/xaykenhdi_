"""Tách nền ảnh người và thêm viền trắng kiểu sticker, để dùng cho ảnh bìa.

    python tools/cutout.py anh-moi.jpg me12            # -> assets/people/me12_sticker.png
    python tools/cutout.py anh-moi.jpg me12 --outline 14

Cần: pip install "rembg[cpu]" (lần đầu chạy sẽ tải model về máy).
"""
import argparse, pathlib
from PIL import Image, ImageFilter

ROOT = pathlib.Path(__file__).resolve().parent.parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image")
    ap.add_argument("name")
    ap.add_argument("--outline", type=int, default=12, help="độ dày viền trắng (px, tính trên ảnh gốc ~1100px chiều cao)")
    ap.add_argument("--model", default="isnet-general-use")
    a = ap.parse_args()

    from rembg import remove, new_session
    src = Image.open(a.image).convert("RGB")
    if src.height > 2000:
        src = src.resize((round(src.width * 2000 / src.height), 2000))
    cut = remove(src, session=new_session(a.model))           # RGBA, nền trong suốt
    alpha = cut.split()[3].point(lambda v: 255 if v > 110 else 0)
    cut.putalpha(alpha)

    pad = a.outline * 3
    big = Image.new("RGBA", (cut.width + pad * 2, cut.height + pad * 2), (0, 0, 0, 0))
    big.paste(cut, (pad, pad), cut)
    mask = big.split()[3]
    k = a.outline * 2 + 1
    ring = mask.filter(ImageFilter.MaxFilter(k if k % 2 else k + 1)).filter(ImageFilter.GaussianBlur(1))
    out = Image.new("RGBA", big.size, (255, 255, 255, 0))
    out.putalpha(ring)
    white = Image.new("RGBA", big.size, (255, 255, 255, 255))
    out = Image.composite(white, out, ring)
    out.alpha_composite(big)
    out = out.crop(out.getbbox())
    dst = ROOT / "assets" / "people" / f"{a.name}_sticker.png"
    out.save(dst)
    print("Đã lưu", dst, out.size)


if __name__ == "__main__":
    main()
