"""Cắt sticker 3D từ ảnh chụp bộ sticker (assets/sticker-sheets/) thành PNG nền trong.

    python tools/extract_stickers.py --list                   # in danh sách ô (số thứ tự, ảnh, vị trí)
    python tools/extract_stickers.py --preview                # tạo assets/sticker-sheets/_tiles.jpg có đánh số để chọn
    python tools/extract_stickers.py 37:phone 39:camera 61:envelope   # cắt ô số 37 lưu thành assets/stickers/phone.png

tiles.json ghi vị trí 137 ô sticker trên 8 ảnh: [chỉ số ảnh, x, y, rộng, cao].
Cần: pip install "rembg[cpu]".
Các sticker đã cắt sẵn: 37 phone, 39 camera, 53 clapper, 61 envelope, 72 newspaper, 34 stars3d, 36 heart3d, 13 star3d, 20 chat3d, 91 clip, 71 seal.
"""
import argparse, json, pathlib
from PIL import Image, ImageDraw

ROOT = pathlib.Path(__file__).resolve().parent.parent
SH = ROOT / "assets" / "sticker-sheets"
T = json.loads((SH / "tiles.json").read_text())
FILES = [SH / f"sheet-{f.split('-')[0]}.png" for f in T["files"]]


def crop(i):
    s, x, y, w, h = T["tiles"][i]
    return Image.open(FILES[s]).convert("RGB").crop((x, y, x + w, y + h))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pick", nargs="*", help="số:tên")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--preview", action="store_true")
    a = ap.parse_args()
    if a.list:
        for i, t in enumerate(T["tiles"]):
            print(i, t)
    if a.preview:
        tw = 120
        cols = 12
        rows = (len(T["tiles"]) + cols - 1) // cols
        S = Image.new("RGB", (cols * (tw + 8) + 8, rows * (tw + 26) + 8), "white")
        d = ImageDraw.Draw(S)
        for i in range(len(T["tiles"])):
            im = crop(i)
            im.thumbnail((tw, tw))
            x, y = 8 + (i % cols) * (tw + 8), 8 + (i // cols) * (tw + 26)
            S.paste(im, (x, y))
            d.text((x, y + tw + 4), str(i), fill="black")
        S.save(SH / "_tiles.jpg", quality=85)
        print("Đã tạo", SH / "_tiles.jpg")
    if a.pick:
        from rembg import remove, new_session
        sess = new_session("isnet-general-use")
        for p in a.pick:
            i, name = p.split(":")
            im = remove(crop(int(i)).resize((lambda c: (c.width * 2, c.height * 2))(crop(int(i))), Image.LANCZOS), session=sess)
            im = im.crop(im.getbbox())
            dst = ROOT / "assets" / "stickers" / f"{name}.png"
            im.save(dst)
            print("Đã lưu", dst)


if __name__ == "__main__":
    main()
