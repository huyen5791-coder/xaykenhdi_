# CLAUDE.md: xưởng carousel @xaykenhdi_

Repo này tự động làm carousel Instagram (và caption) cho kênh **@xaykenhdi_**: kênh dạy chủ tiệm nhỏ xây kênh mạng xã hội, chủ yếu giấu mặt. Người dùng nói tiếng Việt; trả lời bằng tiếng Việt.

## Việc chính

Khi người dùng muốn làm bài mới ("làm carousel về…", "/carousel …", đưa ý tưởng/ghi âm), **làm theo skill `.claude/skills/carousel/SKILL.md`**.

## Bản đồ repo

| Đường dẫn | Nội dung |
| --- | --- |
| `brand/brand.md` | giọng văn, luật thiết kế bìa và slide trong (đọc kỹ, đây là những gì chủ kênh đã sửa nhiều lần) |
| `brand/content-formats.md` | 7 dạng nội dung đã làm + ý tưởng nhân bản |
| `brand/cta.md` | từ khóa comment → tài liệu gửi khách, link Google |
| `brand/captions.md` | cách viết 3 bản caption |
| `brand/palettes.json` | bảng màu, mỗi bài đổi một bảng |
| `engine/render.py` | render `posts/<slug>/post.json` → `output/<slug>/` |
| `engine/SCHEMA.md` | định dạng post.json và các khối nội dung |
| `posts/` | mỗi bài một thư mục: `post.json`, `outline.md`, `captions.md`, `notes.md` |
| `assets/people/` | ảnh chủ kênh đã cắt nền, viền trắng (`_preview.jpg`) |
| `assets/backgrounds/` | ảnh nền thật (`_preview.jpg`) |
| `assets/stickers/` | sticker 3D đã cắt (`_preview.jpg`); `assets/sticker-sheets/` là ảnh gốc 137 sticker |
| `assets/fonts/` | font có tiếng Việt |
| `tools/cutout.py` | cắt nền ảnh người mới + viền trắng |
| `tools/extract_stickers.py` | cắt thêm sticker từ bộ sticker |
| `examples/` | 12 bài đã làm: ảnh xem nhanh, toàn bộ chữ, caption 3 bản |
| `lead-magnets/` | nội dung 4 tài liệu gửi khách |
| `output/` | kết quả render (không commit) |

## Lệnh

```bash
pip install -r requirements.txt && python -m playwright install chromium   # cài một lần; cần thêm ffmpeg
python engine/render.py posts/<slug>              # PNG + cover.mp4 + contact.jpg
python engine/render.py posts/<slug> --no-video   # chỉ PNG
python engine/render.py posts/<slug> --only 1     # chỉ bìa
```

## Luật cứng (tóm tắt, chi tiết trong brand/brand.md)

- Xưng "tui", gọi "các bạn". Ví dụ cụ thể theo ngành. Không gạch ngang dài. Không CTA "follow".
- Bìa: nền ảnh thật mờ nhẹ; người có viền trắng cao 60 đến 65% khung; tiêu đề 1 khối liền; chữ đan lớp với người nhưng chỉ che 1 góc nhỏ chữ cuối, không che mặt; **chỉ dùng sticker 3D thật, không tự vẽ icon**.
- Slide trong: kiểu tạp chí, nền tối, không emoji/icon, chữ ≥ 28px.
- Mỗi bài đổi màu, ảnh người, nền, sticker so với bài trước.
- Số liệu, ngày tháng, tính năng app, luật: kiểm tra trước khi viết, ghi nguồn.
- Luôn xem lại ảnh PNG đã render trước khi báo xong.
