# Các dạng nội dung đã làm và cách nhân bản

12 bài đầu tiên (ảnh xem nhanh trong `examples/finished/`, toàn bộ chữ trong `examples/slides_text_12_bai.txt`) thuộc 7 dạng dưới đây. Bài mới nên chọn 1 dạng, giữ khung slide, thay chủ đề.

## Dạng A: "N dạng kênh cho [nhóm người]"

Đã làm: 10 dạng kênh giấu mặt cho người hướng nội · 7 dạng kênh cho người lớn tuổi · 10 dạng kênh làm cùng nhân viên/người nhà · 8 dạng kênh cho người bận rộn.

- Slide 2: lợi thế / nguyên tắc của nhóm người này (3 đến 4 ý).
- Slide 3 đến 6: mỗi slide 2 dạng. Mỗi dạng: **tên dạng**, mô tả 1 câu, **Vì sao hợp**, **Cách làm**, ví dụ 2 ngành.
- Slide 7: "Bắt đầu thế nào?" (dạng nào trước, dạng nào sau) + bài tập + CTA.

Ý tưởng tiếp: N dạng kênh cho tiệm ở tỉnh nhỏ · cho người mới mở tiệm · cho tiệm chỉ có 1 người · cho người không giỏi nói · cho tiệm bán online kèm offline.

## Dạng B: "N mẫu / N cách [kỹ năng]"

Đã làm: 50 góc quay · 7 câu mở đầu không lộ mặt · 8 cách tạo dấu ấn cá nhân.

- Slide 2: nguyên tắc chung (vì sao kỹ năng này quan trọng).
- Slide giữa: mỗi slide 1 đến 2 mẫu: **Mẫu** (công thức có [chỗ trống]), **Vì sao hiệu quả**, **Cách làm**, ví dụ ngành.
- Slide cuối: cách kết hợp + bài tập + CTA.

Ý tưởng tiếp: 7 kiểu caption ra tin nhắn · 10 ý tưởng video từ 1 lần làm dịch vụ · 6 cách quay đẹp bằng điện thoại cũ · 8 câu kết video khiến khách nhắn tin.

## Dạng C: "Kế hoạch content theo mùa"

Đã làm: Kế hoạch content 11.11 đến Tết.

- Slide 2: toàn cảnh, các mốc kèm **thứ, ngày/tháng/năm** (kiểm tra lịch thật).
- Slide giữa: mỗi slide 1 đến 2 mốc: chuẩn bị khi nào, hợp ngành nào, hâm nóng / cao điểm / sau mốc, ví dụ.
- Slide cuối: lịch chuẩn bị theo tháng + bài tập + CTA.

Ý tưởng tiếp: content mùa cưới · mùa tựu trường · 8/3 và 20/10 · mùa hè · Valentine (14/02/2027 là mùng 9 Tết).

## Dạng D: "Quy trình N bước để [kết quả]"

Đã làm: Cách chốt lịch kín tiệm mùa Tết · Khách tìm tiệm trên social như Google.

- Slide 2: hiểu vấn đề / tâm lý khách / cách nền tảng hoạt động.
- Slide 3 đến 6: mỗi slide 1 bước, có so sánh ĐỪNG / NÊN khi phù hợp.
- Slide 7: lộ trình theo thời gian hoặc checklist + bài tập + CTA.

Ý tưởng tiếp: quy trình trả lời tin nhắn ra lịch hẹn · quy trình xin đánh giá 5 sao · biến khách mới thành khách quen · tối ưu Google Maps cho tiệm.

## Dạng E: "N lời khuyên sai / hiểu lầm"

Đã làm: 5 lời khuyên sai xây kênh phổ biến nhưng sai với tiệm nhỏ.

- Slide 2: vì sao không hợp (so sánh người làm nội dung chuyên nghiệp và tiệm nhỏ).
- Slide giữa: mỗi lời khuyên: VÌ SAO KHÔNG HỢP, NÊN LÀM GÌ THAY, ví dụ.
- Slide cuối: bảng tóm lại (sai → đúng) + lời mời tranh luận + CTA.

Ý tưởng tiếp: 6 hiểu lầm về thuật toán · 5 sai lầm khi chụp ảnh thành phẩm · 7 điều chủ tiệm hay làm khiến khách không quay lại.

## Dạng F: "Có nên [việc] không? Khi nào nên, khi nào chưa"

Đã làm: Có nên chạy quảng cáo cho tiệm nhỏ? (file mẫu đầy đủ: `posts/12-co-nen-chay-quang-cao/post.json`)

- Slide 2: hình ảnh so sánh dễ nhớ (quảng cáo là cái loa).
- Slide 3: N dấu hiệu CHƯA NÊN. Slide 4: hậu quả nếu làm sớm. Slide 5: dấu hiệu ĐÃ SẴN SÀNG + ví dụ tính toán.
- Slide 6: N bước làm với ngân sách nhỏ. Slide 7: checklist + bài tập + CTA.

Ý tưởng tiếp: Có nên giảm giá? · Có nên thuê người quay video? · Có nên làm KOC/KOL? · Có nên mở thêm chi nhánh trên mạng?

## Dạng G: "N dạng video cụ thể cho 1 ngành"

Chưa làm, hợp để nhân bản: 10 ý tưởng video cho tiệm nail · cho quán cà phê · cho spa · cho tiệm tóc nam.

## Cách chọn chủ đề tiếp theo

1. Xem `posts/` và `examples/` để không trùng chủ đề.
2. Ưu tiên chủ đề gắn mùa sắp tới (kiểm tra ngày hôm nay).
3. Xen kẽ dạng: không đăng 2 bài cùng dạng liền nhau.
