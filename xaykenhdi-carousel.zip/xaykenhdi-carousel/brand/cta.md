# Từ khóa comment và tài liệu gửi khách

| Từ khóa | Khách nhận | Dùng cho |
| --- | --- | --- |
| **KÊNH** | 1. Bộ tài liệu xây kênh cho tiệm nhỏ | Mặc định cho hầu hết bài |
| **XAYKENH** | 1. Bộ tài liệu xây kênh + 2. Tài liệu AI (30 câu lệnh) + 3. Hướng dẫn AI edit video (CapCut) | Bài về quay, dựng, công cụ, AI |
| **KÊNH** (bài quảng cáo) | 1. Bộ tài liệu xây kênh + 4. Bảng tính chi phí chạy quảng cáo | Bài về quảng cáo, ngân sách |

Câu CTA chuẩn ở slide cuối:

- KÊNH: "COMMENT **KÊNH** để tui gửi các bạn bộ tài liệu xây kênh cực chi tiết, từ chọn ngách, lên nội dung đến ra đơn."
- XAYKENH: "comment **XAYKENH**, tui gửi các bạn trọn bộ: ✓ tài liệu xây kênh ✓ tài liệu AI ✓ hướng dẫn dùng AI edit video"

Nếu bài mới cần tài liệu mới (ví dụ mẫu tin nhắn chốt lịch), đề xuất từ khóa mới và tạo tài liệu trong `lead-magnets/`, rồi thêm dòng vào bảng này.

## Link bản Google (đang dùng)

- Folder: https://drive.google.com/drive/folders/10M0hmyss7a9IVIfCtv_0XKuwT_SXCozR
- 1. Bộ tài liệu xây kênh: https://docs.google.com/document/d/1TiyjdRGwTDYBAHEWqh6ICwyLXwcAUDkBd4hH21Q5BqE/edit
- 2. Tài liệu AI, 30 câu lệnh: https://docs.google.com/document/d/1Rj8z5In86JREDHU_Wj_bb0JkIyUYPTe2Rn6Gd9EPCm8/edit
- 3. Hướng dẫn AI edit video (CapCut): https://docs.google.com/document/d/1--occcUjRCZhbCTrRhLIVe8K80SQABWFXe0_zDDUj6o/edit
- 4. Bảng tính chi phí chạy quảng cáo: https://docs.google.com/spreadsheets/d/12PvMzheD0WQRInmXhkjlkp2B_0yHMkLiChcOSUYcvEQ/edit

Bản sao nội dung nằm trong `lead-magnets/`.
