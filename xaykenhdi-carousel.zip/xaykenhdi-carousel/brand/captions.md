# Viết caption

Mỗi bài có **3 bản caption**, lưu vào `posts/<slug>/captions.md`. Ví dụ đầy đủ cho 12 bài: `examples/captions/`.

## Phần chung cho cả 3 bản

- Giọng "tui" / "các bạn". Không emoji (hoặc tối đa 1). Không gạch ngang dài.
- Kết thúc bằng câu CTA đúng từ khóa của bài (xem `brand/cta.md`), rồi 5 hashtag: luôn có `#xaykenh` và `#tiemnho`, 3 cái còn lại sát chủ đề (ví dụ `#kenhgiaumat #hookvideo #chotlich #muatet #seotiktok`).
- Dưới 1.500 ký tự (Instagram giới hạn 2.200).
- Bài về tìm kiếm / SEO: câu đầu caption phải chứa từ khóa chính.

## Bản ngắn

1. Câu mở đầu: chạm đúng nỗi lo của chủ tiệm (câu hỏi hoặc khẳng định).
2. 1 đoạn tóm tắt nội dung bài (liệt kê các mục chính).
3. 1 câu hành động (lưu lại, thử ngay, gửi cho ai).
4. CTA + hashtag.

## Version 1: Kể chuyện thân thiện

1. Mở bằng **một cảnh quen** trong đời chủ tiệm (9 giờ tối đóng cửa, 28 Tết điện thoại reo, nạp tiền quảng cáo mà không ai nhắn…). Viết như tình huống chung, **không bịa chuyện riêng của chủ kênh**.
2. Chuyển sang nội dung bài một cách tự nhiên.
3. **1 mẹo/kiến thức chưa có trên slide**, viết như đang tâm sự.
4. CTA + hashtag.

## Version 2: Bổ sung kiến thức

1. 1 câu đi thẳng vào điểm chính của bài.
2. "Ngoài slide, …" rồi **3 đến 4 ý kiến thức mới, đánh số**, không lặp lại slide. Mỗi ý 1 đến 2 câu, có con số hoặc thao tác cụ thể.
3. CTA + hashtag.

Kiến thức bổ sung phải đúng: tính năng ứng dụng, luật, ngày tháng đều kiểm tra trước. Không chắc thì bỏ.
