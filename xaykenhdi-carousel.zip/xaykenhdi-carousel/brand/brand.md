# Thương hiệu @xaykenhdi_

## Kênh là ai, nói với ai

- Kênh: **@xaykenhdi_**. Chủ đề: dạy chủ tiệm nhỏ (tóc, nail, spa, quán ăn, cà phê, tiệm may, shop thời trang nhỏ) xây kênh mạng xã hội để có khách, phần lớn là kênh **giấu mặt** hoặc ít lộ mặt.
- Người đọc: chủ tiệm bận rộn, ngại công nghệ, ngại lên hình, không có ngân sách lớn. Họ cần thứ làm được ngay trong tiệm, bằng điện thoại.
- Xưng hô: **"tui"** và **"các bạn"**. Trong slide trong có thể dùng "bạn" khi nói trực tiếp với người đọc.
- Giọng: thân thiện, thẳng, thực tế, không "lùa gà", không hứa hẹn quá đà. Kiến thức nhiều, ví dụ cụ thể theo từng ngành.

## Luật viết

1. Mỗi ý có **ví dụ theo ngành**: "Nail: …", "Tóc: …", "Spa: …", "Quán ăn: …", "Cà phê: …". Ví dụ phải cụ thể (tên dịch vụ, tình huống thật ở tiệm).
2. Không dùng dấu gạch ngang dài (—) để nối câu. Dùng dấu phẩy, dấu hai chấm hoặc tách câu.
3. Câu ngắn, dễ đọc. Không sáo rỗng ("bùng nổ", "đỉnh cao", "bí kíp thần thánh").
4. Số liệu, ngày tháng, tính năng ứng dụng, quy định pháp luật: **phải kiểm tra** trước khi viết. Có số liệu thì ghi nguồn ngắn ngay trong slide (ví dụ "Theo khảo sát của Adobe Express năm 2026 (tại Mỹ)"). Không chắc thì viết chung chung hoặc bỏ.
5. Số trong ví dụ tiền bạc phải ghi rõ "giả định" hoặc "ví dụ".
6. Khan hiếm, ưu đãi: luôn nhắc phải là thật, không dạy nói dối khách.
7. Hình khách, tin nhắn khách: luôn nhắc xin phép và che tên, số điện thoại.
8. Không có lời mời "follow để xem thêm" (chủ kênh thấy thương mại quá). Chỉ có "Lưu bài này" và "COMMENT <TỪ KHÓA>".

## Kích thước và cấu trúc bài

- 1080 × 1350 PNG (Instagram 4:5). Thường **7 slide** (được 6 đến 8).
- Slide 1: bìa (có thêm bản video động 5 giây lặp).
- Slide 2: nền tảng / vì sao / hiểu vấn đề.
- Slide 3 đến N-1: nội dung chính, mỗi slide 2 đến 3 mục hoặc 1 danh sách.
- Slide cuối: tổng kết / checklist / kế hoạch + **Bài tập** + khung CTA (Lưu bài này + COMMENT TỪ KHÓA + lời hứa tài liệu).

## Bìa (slide 1): luật bắt buộc

Đây là những điều chủ kênh đã sửa nhiều lần, làm sai là bị chê ngay:

- **Nền là ảnh thật**, chỉ làm mờ nhẹ (không mờ nhoè), không có địa danh nhận ra được. Dùng ảnh trong `assets/backgrounds/`.
- **Ảnh chủ kênh** cắt nền, có **viền trắng** kiểu sticker, cao khoảng **60 đến 65% khung** (≈ 800 đến 880px). Không để người quá to. Ảnh trong `assets/people/`, đổi ảnh khác bài trước.
- **Tiêu đề là một khối chữ liền**, các dòng sát nhau. Không rải chữ lung tung, không để khoảng trống lớn giữa các dòng (engine tự xếp bằng `gap`).
- **Hiệu ứng lớp (layer)**: chữ và người đan xen. Một dòng chữ to nằm **sau** người (`tuck`) và chỉ bị che **một góc nhỏ của chữ cuối**. Không bao giờ che hẳn một chữ, không bao giờ che mặt. Các dòng khác nằm **trước** người.
- Cỡ chữ to, rõ, đọc được khi lướt ở kích thước nhỏ. Kiểu dòng: chữ đậm trắng (big), chữ đậm màu nhấn có viền trắng (accent), chữ nghiêng viết tay (script), khung pill.
- **Icon chỉ dùng sticker 3D/ảnh thật** trong `assets/stickers/` (cắt từ bộ sticker của chủ kênh). **Tuyệt đối không tự vẽ icon** bằng SVG/emoji. 5 đến 7 sticker, rải ở góc và mép, không đè lên chữ hay mặt.
- Nhãn `xaykenhdi_` ở góc trên trái (pill xanh có tim vàng, hoặc kiểu đen).
- Mỗi bài **đổi màu nhấn, đổi bộ sticker, đổi ảnh người, đổi ảnh nền** so với bài trước.

## Slide trong: kiểu "tạp chí"

- Nền ảnh thật làm tối nhẹ, nhãn `xaykenhdi_` khối màu ở góc trên trái, tiêu đề 2 dòng góc trên phải: dòng chữ đặc trắng + dòng chữ viền màu nhấn.
- Chữ nội dung font có chân (Termes), căn đều, cỡ 30 đến 34px. **Không emoji, không icon** ở slide trong.
- Dùng màu nhấn cho: số mục, highlight (`<mark>`), nhãn mẹo, ô checklist.
- Nội dung tối đa vừa khung ở cỡ chữ ≥ 28px. Engine báo "chữ đã thu nhỏ" thì cắt bớt chữ, không nhồi.

## Màu

Bảng màu nằm trong `brand/palettes.json`. Màu gốc của kênh: #fbf9ed, #4d554a, #503c36, #cdfe84, #f2a0d6, #fffd60. Mỗi bài chọn một bảng khác bài liền trước; có thể tạo bảng mới (thêm vào palettes.json) miễn là màu nhấn sáng, đọc rõ trên nền tối.

## Font

- Bìa: Be Vietnam Pro 900 (BVP), Playfair Display italic (PFD).
- Slide trong: Anton (tiêu đề), TeX Gyre Termes (nội dung), Montserrat (nhãn).
- Tất cả có sẵn trong `assets/fonts/`, hỗ trợ tiếng Việt.
