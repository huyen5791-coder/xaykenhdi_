# Ảnh nền

Xem nhanh: `_preview.jpg`.

| Dùng cho bìa (rõ vừa, không địa danh) | Chỉ dùng cho slide trong |
| --- | --- |
| bg_tree2, bg_tree, bg_wall, bg_terrace, bg_cafe_mid, bg_cafe_top, bg_awning, bg_shutter, bg_door, bg_planter, bg_hedge, bg_stone, bg_pave, bg_road, bg_plaza2, bg_lamp | bg_plaza, bg_lamp2 (có người qua đường, kiến trúc dễ nhận ra), bg_gate, bg_street, bg_sidewalk, bg_wall_soft (đã mờ nhiều, bìa sẽ bị chê "nền mờ quá") |

Thêm ảnh nền mới: chụp hoặc chọn ảnh dọc, thêm vào thư mục này (≥ 1080×1350, không có người, không biển hiệu/địa danh rõ), rồi chạy lại phần tạo `_preview.jpg` (nhờ Claude).
