Anton, Montserrat, Be Vietnam Pro, Playfair Display: SIL Open Font License 1.1 (xem LICENSE-OFL.txt), lấy từ Fontsource.
TeX Gyre Termes: GUST Font License.
