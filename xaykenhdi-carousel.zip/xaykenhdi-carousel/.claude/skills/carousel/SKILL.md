---
name: carousel
description: Làm một carousel Instagram hoàn chỉnh cho kênh @xaykenhdi_ (slide PNG 1080x1350, video bìa động, 3 bản caption) từ một chủ đề hoặc ghi chú. Dùng khi người dùng nói "làm carousel", "làm bài mới", "/carousel <chủ đề>", hoặc đưa ý tưởng bài đăng.
---

# Quy trình làm carousel @xaykenhdi_

Đọc trước (lần đầu trong phiên): `brand/brand.md`, `brand/content-formats.md`, `brand/cta.md`, `brand/captions.md`, `engine/SCHEMA.md`, và file mẫu `posts/12-co-nen-chay-quang-cao/post.json`.

## 1. Chốt chủ đề và dạng

- Lấy chủ đề từ người dùng. Nếu chỉ nói "làm bài mới", đề xuất 3 chủ đề từ `brand/content-formats.md` (không trùng bài đã có trong `posts/` và `examples/`), hỏi chọn.
- Chọn **dạng nội dung** (A đến G) và số slide (mặc định 7).
- Chủ đề có số liệu, ngày tháng, tính năng ứng dụng, luật: tìm kiếm và kiểm tra trước khi viết. Ghi nguồn vào `posts/<slug>/notes.md`.

## 2. Viết chữ trước, duyệt rồi mới thiết kế

- Viết toàn bộ chữ các slide vào `posts/<slug>/outline.md`: tiêu đề bìa (dưới 10 chữ, chia 3 đến 4 dòng), rồi từng slide (tiêu đề 2 dòng + nội dung).
- Theo luật viết trong `brand/brand.md`: ví dụ theo ngành, xưng "tui/các bạn", không gạch ngang dài, không emoji ở slide trong, không "follow".
- Slide cuối luôn có **Bài tập** + khung CTA đúng từ khóa (`brand/cta.md`).
- **Dừng lại cho người dùng duyệt outline** (trừ khi họ nói "làm luôn"/"tự động").

## 3. Chọn hình ảnh (khác bài trước)

Mở `posts/*/post.json` gần nhất để tránh lặp:

- `palette`: bảng màu khác bài liền trước (`brand/palettes.json`).
- `cover.person`: ảnh người khác bài trước (xem `assets/people/_preview.jpg`).
- `cover.background` và nền slide trong: ảnh khác nhau trong `assets/backgrounds/` (xem `_preview.jpg`), mỗi slide 1 nền, có thể `flip`.
- `cover.stickers`: 5 đến 7 sticker hợp chủ đề, bộ khác bài trước (xem `assets/stickers/_preview.jpg`). Thiếu sticker hợp chủ đề thì cắt thêm từ bộ sticker: `python tools/extract_stickers.py --preview` để xem ô, chọn ô không có nhãn "EDU", rồi `python tools/extract_stickers.py 84:hoa-tulip`. **Không tự vẽ icon.**

## 4. Viết `posts/<slug>/post.json`

Theo `engine/SCHEMA.md`. Bìa: 3 đến 4 dòng; đúng 1 dòng `tuck: true` (dòng chữ to nhất, thường `accent`); các dòng sát nhau bằng `gap` nhỏ (−30 đến 25).

## 5. Render và tự kiểm tra

```bash
python engine/render.py posts/<slug> --no-video     # nhanh, để sửa
python engine/render.py posts/<slug>                # bản cuối, có cover.mp4
```

Mở `output/<slug>/contact.jpg` và **xem từng slide PNG** (đọc ảnh), đối chiếu checklist:

- [ ] Bìa: tiêu đề là 1 khối liền, đọc rõ ở kích thước nhỏ, không chữ nào bị che hẳn, mặt không bị che.
- [ ] Dòng tuck chỉ bị người che 1 góc nhỏ chữ cuối.
- [ ] Người cao khoảng 60 đến 65% khung, có viền trắng. Nền mờ nhẹ, không quá mờ.
- [ ] Sticker không đè chữ, không đè mặt, không bị cắt mất ở mép.
- [ ] Slide trong: không chữ tràn, cỡ chữ ≥ 28px (xem log), tiêu đề 2 dòng không bị bóp nhỏ.
- [ ] Không lỗi chính tả, dấu tiếng Việt hiển thị đúng.
- [ ] Màu, ảnh người, nền, sticker khác bài trước.

Sửa `post.json` rồi render lại (`--only 1` để chỉ render bìa). Tối đa 3 vòng tự sửa, sau đó cho người dùng xem.

## 6. Caption

Viết 3 bản (ngắn, kể chuyện, kiến thức) theo `brand/captions.md` vào `posts/<slug>/captions.md`.

## 7. Báo kết quả

Trả lời ngắn: đường dẫn `output/<slug>/` (slide-1…N.png, cover.mp4, contact.jpg), `posts/<slug>/captions.md`, từ khóa CTA và tài liệu cần gửi khách. Nếu cần tài liệu mới cho CTA, nói rõ.

## Làm nhiều bài một lúc

Người dùng đưa danh sách chủ đề: làm outline cho tất cả trước, cho duyệt một lần, rồi render lần lượt. Mỗi bài vẫn đổi màu, người, nền, sticker so với bài trước nó.

## Khi người dùng góp ý

- Sửa đúng chỗ được nói, không đổi phần khác.
- Góp ý về **gu thẩm mỹ chung** (không riêng bài này): cập nhật thêm vào `brand/brand.md` mục luật bìa/slide trong, để lần sau không lặp lỗi.
