# Caption: Có nên chạy quảng cáo cho tiệm nhỏ?

## Bản ngắn

Bấm nút quảng cáo vài trăm nghìn, vài triệu, rồi tiền hết mà khách vẫn không thấy đâu? Quảng cáo không tạo ra khách, nó chỉ là cái loa đưa video đến nhiều người hơn.

Trong bài: 6 dấu hiệu chưa nên chạy, vì sao nội dung chưa tốt thì quảng cáo cũng không cứu được, dấu hiệu đã sẵn sàng, 6 bước chạy với ngân sách nhỏ và checklist 8 ô trước khi bấm nút.

Trước khi chạy, tính xem một khách mới đáng giá bao nhiêu với tiệm mình.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh kèm bảng tính chi phí chạy quảng cáo, điền số là biết nên tăng, giữ hay dừng.

#xaykenh #chayquangcao #quangcaotiktok #quangcaofacebook #tiemnho

## Version 1: Kể chuyện

Nạp vài trăm nghìn chạy quảng cáo, sáng ra thấy video lên mấy nghìn lượt xem, mừng lắm. Nhưng hết ngày không có ai nhắn tin hỏi giá. Nghe quen không?

Quảng cáo không tạo ra khách, nó chỉ là cái loa. Video chưa hay, trang chưa chỉn chu, tin nhắn trả lời chậm thì loa càng to càng tốn tiền. Tui gom 6 dấu hiệu chưa nên chạy, dấu hiệu đã sẵn sàng và 6 bước chạy với ngân sách nhỏ.

Khi chạy rồi, đừng sửa quảng cáo liên tục trong mấy ngày đầu. Hệ thống cần vài ngày để tìm đúng người xem, sửa giữa chừng là nó phải học lại từ đầu. Chạy đủ 5 đến 7 ngày rồi hãy đánh giá.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh kèm bảng tính chi phí chạy quảng cáo, điền số là biết nên tăng, giữ hay dừng.

#xaykenh #chayquangcao #quangcaotiktok #quangcaofacebook #tiemnho

## Version 2: Kiến thức

Quảng cáo không tạo ra khách, nó chỉ đưa video đến nhiều người hơn. Trước khi bấm nút, tính 3 con số này:

1. Trần chi cho 1 khách mới = số nhỏ hơn giữa "lãi 1 lần làm" và "30% lãi 1 khách mang lại cả năm". Ví dụ lãi 100.000đ mỗi lần, khách đến 4 lần/năm thì trần là 100.000đ.
2. Ngân sách chạy thử = chi phí 1 tin nhắn × 20 đến 30 tin nhắn, chia đều 5 đến 7 ngày.
3. Chi phí 1 khách thật = tổng tiền chi ÷ số khách đến tiệm. Dưới trần thì tăng ngân sách từ từ, vượt trần thì dừng và xem lại video hoặc khâu tin nhắn.

Thêm 2 lưu ý: đừng sửa quảng cáo liên tục vài ngày đầu vì hệ thống cần thời gian tìm đúng người; dùng mã ưu đãi riêng cho khách từ quảng cáo để đếm cho đúng.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh kèm bảng tính chi phí chạy quảng cáo, điền số là biết nên tăng, giữ hay dừng.

#xaykenh #chayquangcao #quangcaotiktok #quangcaofacebook #tiemnho
