# Xưởng carousel @xaykenhdi_

Repo này giúp Claude Code tự làm carousel Instagram cho kênh @xaykenhdi_. Bạn đưa chủ đề, Claude viết chữ, chọn hình, render slide PNG 1080×1350, video bìa động 5 giây, và 3 bản caption. Mọi thứ giữ đúng phong cách 12 bài đã làm.

## 1. Đưa lên GitHub

1. Vào github.com, bấm **New repository**, đặt tên (ví dụ `xaykenhdi-carousel`), chọn **Private**, bấm **Create**.
2. Giải nén file zip, kéo toàn bộ nội dung thư mục `xaykenhdi-carousel` vào trang repo (mục **uploading an existing file**), bấm **Commit**.
   Hoặc dùng dòng lệnh:
   ```bash
   cd xaykenhdi-carousel
   git init && git add . && git commit -m "Xưởng carousel xaykenhdi_"
   git branch -M main
   git remote add origin https://github.com/<tên-bạn>/xaykenhdi-carousel.git
   git push -u origin main
   ```

## 2. Mở trong Claude Code

Mở repo trong Claude Code (trên web chọn repo vừa tạo, hoặc trên máy `cd xaykenhdi-carousel && claude`). Claude tự đọc `CLAUDE.md` và biết cách làm.

Lần đầu, nói: **"Cài đặt môi trường cho repo này"**. Claude sẽ chạy:

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

và kiểm tra có `ffmpeg` (để xuất video bìa).

## 3. Làm bài mới

Gõ một trong các câu sau:

- `/carousel 7 kiểu caption khiến khách nhắn tin hỏi giá`
- "Làm carousel dạng *có nên… không* về chủ đề: có nên giảm giá để kéo khách?"
- "Đề xuất 3 chủ đề tiếp theo cho kênh rồi làm bài đầu tiên."
- "Làm 4 bài cho tháng 12: … , … , … , …" (Claude làm outline cả 4 cho bạn duyệt một lần)
- "Làm luôn không cần hỏi: 10 ý tưởng video cho quán cà phê"

Claude sẽ:

1. Viết chữ toàn bộ slide vào `posts/<tên-bài>/outline.md` và hỏi bạn duyệt.
2. Chọn màu, ảnh của bạn, ảnh nền, sticker 3D (khác bài trước).
3. Render ra `output/<tên-bài>/`: `slide-1.png` … `slide-7.png`, `cover.mp4`, `contact.jpg` (ảnh ghép xem nhanh).
4. Tự xem lại từng slide theo checklist và sửa.
5. Viết 3 bản caption vào `posts/<tên-bài>/captions.md`.

Muốn sửa, cứ nói tự nhiên: "bìa chữ to hơn", "đổi ảnh người khác", "slide 4 bớt chữ", "đổi màu hồng". Góp ý về gu chung (ví dụ "đừng bao giờ dùng màu tím") Claude sẽ ghi vào `brand/brand.md` để nhớ cho các bài sau.

## 4. Thêm ảnh mới của bạn

Đưa ảnh toàn thân (đứng, nền gì cũng được) vào repo, rồi nói: "Cắt nền ảnh `anh-moi.jpg` thành ảnh người mới". Claude chạy `tools/cutout.py`, ảnh mới có viền trắng nằm trong `assets/people/`.

## 5. Thêm sticker

- Cắt thêm từ bộ sticker có sẵn: "Thêm sticker hoa tulip và con gấu từ bộ sticker".
- Có bộ sticker mới: chụp màn hình bộ sticker, đưa vào `assets/sticker-sheets/`, nhờ Claude cắt.

Lưu ý: một số ô trong bộ sticker hiện tại có nhãn "EDU" của ứng dụng, Claude sẽ tránh các ô đó.

## Thư mục

```
CLAUDE.md                     hướng dẫn cho Claude Code
.claude/skills/carousel/      quy trình làm 1 bài (gõ /carousel)
brand/                        giọng văn, luật thiết kế, dạng nội dung, CTA, caption, bảng màu
engine/render.py              máy render
engine/SCHEMA.md              cấu trúc file post.json
posts/                        mỗi bài 1 thư mục (bài 12 là mẫu đầy đủ)
assets/                       font, ảnh người, ảnh nền, sticker
tools/                        cắt nền ảnh người, cắt sticker
examples/                     12 bài đã làm, caption 3 bản
lead-magnets/                 4 tài liệu gửi khách
```
