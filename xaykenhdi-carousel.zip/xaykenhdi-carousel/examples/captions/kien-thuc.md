# Caption 12 carousel @xaykenhdi_ - Version 2 - Kiến thức

## Bài 1 đến 4

### 1. 50 góc quay cho kênh giấu mặt

50 góc quay không cần lộ mặt, chia 6 nhóm trên slide. Dưới đây là 4 điều giúp góc nào quay ra cũng nét hơn:

1. Khóa lấy nét: chạm và giữ vào chủ thể trên màn hình cho đến khi điện thoại báo khóa. Tay di chuyển trong khung mà hình không bị mờ, không chớp sáng tối.
2. Không zoom bằng hai ngón tay. Muốn cận cảnh thì đưa máy lại gần, vì zoom trên điện thoại thường làm vỡ hình.
3. Mỗi cảnh quay dư 2 giây ở đầu và cuối để có chỗ cắt khi ghép.
4. Quay dọc, để 1080p và 30 khung hình/giây là đủ cho video ngắn, nhẹ máy mà vẫn nét.

Lưu bài lại, mỗi tuần chọn vài góc quay dần.

Comment "XAYKENH", tui gửi các bạn trọn bộ: tài liệu xây kênh, tài liệu AI và hướng dẫn dùng AI edit video.

#xaykenh #kenhgiaumat #gocquay #quayvideobangdienthoai #tiemnho

### 2. 10 dạng kênh giấu mặt cho người hướng nội

Giấu mặt vẫn hiệu quả nếu thay khuôn mặt bằng đôi tay, giọng nói, phong cách và kết quả thật. Ngoài 10 dạng trên slide, các bạn nên biết thêm:

1. Luôn bật phụ đề. Nhiều người lướt video khi đang tắt tiếng, kênh giấu mặt không có nét mặt để họ đoán ý, nên chữ phải nói thay.
2. Ưu tiên giọng thật hơn giọng đọc AI. Giọng AI tiện nhưng nhiều kênh dùng chung một giọng, còn giọng thật là dấu ấn riêng của các bạn.
3. Giữ 2 đến 3 dạng trong vài tuần đầu. Đăng lặp lại một kiểu giúp người xem nhớ kênh, cũng giúp các bạn quay nhanh hơn mỗi lần.
4. Có tay, đồ dùng hay tin nhắn của khách trong khung hình thì xin phép trước và che tên, số điện thoại.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #kenhgiaumat #nguoihuongnoi #tiemnho #kinhdoanhonline

### 3. 7 dạng kênh cho người lớn tuổi, ngại công nghệ

Kinh nghiệm nhiều năm là lợi thế lớn nhất khi làm kênh. Để video nhìn và nghe rõ mà vẫn đơn giản, các cô chú lưu ý thêm:

1. Ngồi quay mặt về phía cửa sổ hoặc cửa tiệm, đừng ngồi quay lưng ra cửa. Ngược sáng thì mặt và tay sẽ bị tối.
2. Đặt điện thoại cách mình dưới 1 mét. Tiệm ồn thì mua thêm 1 micro cài áo cắm vào điện thoại, giọng sẽ rõ hơn nhiều.
3. Bắt đầu với video 30 giây đến 1 phút, mỗi video nói 1 ý. Ngắn thì dễ quay lại khi lỡ vấp.
4. Nhờ con cháu bật thông báo bình luận. Trả lời bình luận sớm là cách kéo khách về tiệm nhanh nhất.

Gửi bài này cho bố mẹ, cô chú đang có tiệm nhé.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #tiemgiadinh #nguoilontuoi #kinhdoanhnho #tiemnho

### 4. 7 câu mở đầu video không cần lộ mặt

Giây đầu tiên phải có ít nhất 2 trong 3: hình có điểm nhấn, âm thanh ngay giây 0, chữ dưới 10 từ. 7 mẫu nằm trên slide, còn đây là 4 lỗi hay gặp khi áp dụng:

1. Mở đầu bằng lời chào "Xin chào các bạn, hôm nay mình...". Dời lời chào ra sau câu mở đầu.
2. Chữ và lời nói không khớp nhau. Giây đầu nên cùng 1 thông điệp, người xem bật hay tắt tiếng đều hiểu.
3. Hứa một đằng, video nói một nẽo. Câu mở đầu hứa gì thì video phải trả đúng cái đó, nếu không người xem bỏ ngang và lần sau lướt qua kênh.
4. Ảnh bìa nói chuyện khác. Ảnh bìa là thứ khách thấy trên trang cá nhân, nên dùng lại đúng câu mở đầu làm tiêu đề bìa.

Lưu lại, mỗi lần quay mở ra chọn 1 mẫu.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #hookvideo #caumodau #kenhgiaumat #tiemnho

## Bài 5 đến 8

### 5. 10 dạng kênh làm cùng nhân viên hoặc người nhà

Làm kênh cùng đội ngũ giúp bớt áp lực, nhiều ý tưởng và tạo niềm tin. Trước khi quay, các bạn nắm thêm 4 điều:

1. Hình ảnh của nhân viên thuộc về chính họ. Bộ luật Dân sự 2015 (Điều 32) quy định dùng hình ảnh của một người phải được người đó đồng ý. Xin đồng ý bằng tin nhắn cho rõ ràng.
2. Thống nhất trước chuyện video cũ khi nhân viên nghỉ việc: giữ, ẩn hay gỡ.
3. Luân phiên người lên hình và quay theo buổi 20 đến 30 phút lúc vắng khách, đừng để 1 người gánh hết.
4. Gắn tài khoản của nhân viên vào video. Họ vui khi được ghi tên, hay chia sẻ lại, video đến thêm bạn bè của họ.

Tag người các bạn muốn rủ quay cùng nha.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #tiemgiadinh #hautruong #ytuongvideo #tiemnho

### 6. 8 dạng kênh cho người bận rộn, chỉ 2 tiếng mỗi tuần

2 tiếng mỗi tuần đủ cho 6 đến 8 bài nếu chọn đúng dạng nội dung. 4 cách tiết kiệm thêm thời gian ngoài slide:

1. Hẹn giờ đăng cả tuần: Facebook và Instagram trong Meta Business Suite, TikTok khi đăng từ máy tính.
2. Đăng 1 video lên nhiều nền tảng bằng file gốc. Video tải về từ TikTok có logo TikTok, Instagram từng nói sẽ ít đề xuất video mang logo ứng dụng khác.
3. Lưu sẵn tin nhắn nhanh cho 5 câu khách hay hỏi. Trả lời bình luận và tin nhắn chỉ còn vài giây.
4. Tạo 1 ghi chú "Câu khách hỏi" trong điện thoại. Khách hỏi gì ghi lại ngay, cuối tuần đó là danh sách ý tưởng.

Lưu lại để làm theo mỗi tuần.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #chutiem #lamkenhnhanh #kehoachcontent #tiemnho

### 7. 8 cách tạo dấu ấn cá nhân cho kênh không lộ mặt

Dấu ấn cá nhân là "khuôn mặt thay thế" của kênh giấu mặt. Ngoài 8 cách trên slide, để dấu ấn bền và không trùng ai:

1. Ảnh bìa đồng bộ: cùng kiểu chữ, cùng vị trí tiêu đề. Khách bấm vào trang sẽ thấy cả lưới ảnh bìa trước khi xem video nào.
2. Lưu 2 đến 3 mã màu và font của kênh vào Canva và CapCut, để ai trong tiệm làm video cũng ra cùng một kiểu.
3. Âm thanh nhận diện nên tự thu từ nghề (tiếng kéo, tiếng rót), đừng lấy đoạn nhạc có bản quyền vì có thể bị tắt tiếng.
4. Trước khi chốt câu chào riêng, gõ thử vào ô tìm kiếm TikTok xem kênh nào đã dùng chưa.

Dấu ấn cần lặp lại qua 20 đến 30 video mới thành. Kiên nhẫn nha.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #kenhgiaumat #thuonghieucanhan #nhandien #tiemnho

### 8. Kế hoạch content mùa cuối năm, từ 11.11 đến Tết

Mùng 1 Tết Nguyên đán là thứ 7, 06/02/2027. Ngoài 6 mốc trên slide, còn mấy điều các bạn nên ghi vào lịch:

1. 20/11 (Ngày Nhà giáo Việt Nam): hợp tiệm có quà tặng, spa, nail bán thẻ quà cho phụ huynh tặng cô giáo.
2. Lễ Tình nhân 14/02/2027 rơi vào mùng 9 Tết. Khách làm đẹp Tết và Valentine gần như cùng lúc, nên mở lịch sau Tết sớm hơn mọi năm.
3. Bán thẻ quà tặng hoặc gói dịch vụ trả trước từ tháng 11: tiệm có tiền trước Tết, khách có quà cuối năm.
4. Đăng lịch nghỉ Tết và ngày mở cửa lại từ giữa tháng 1, ghim lên đầu trang để khách không phải hỏi.

Tiệm tóc, nail, spa dồn sức vào Noel và Tết là đủ, không cần chạy hết các mốc.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #kehoachcontent #muatet #contentcuoinam #tiemnho

## Bài 9 đến 12

### 9. Cách chốt lịch kín tiệm mùa Tết từ bây giờ

Chốt lịch Tết sớm là giúp khách đặt trước, để tiệm không quá tải sát Tết rồi vắng đầu tháng 1. Bổ sung cho 4 bước trên slide:

1. Nhận cọc bằng mã QR, nhờ khách ghi nội dung chuyển khoản là "tên + giờ hẹn" để đối chiếu nhanh, không nhầm lịch.
2. Niêm yết giá Tết và phụ thu (nếu có) ngay khi mở đặt lịch. Khách biết trước thì không bất ngờ lúc thanh toán.
3. Cài tin nhắn trả lời tự động trên Messenger hoặc Zalo, báo khách biết trong bao lâu tiệm sẽ phản hồi.
4. Xếp ca làm và ngày nghỉ của thợ trước khi mở lịch. Sức chứa chỉ đúng khi biết chắc ai làm ngày nào.

Khan hiếm phải là thật: "Chiều 28 Tết còn 3 khung giờ", không phải "SẮP HẾT CHỖ!!!".

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, có sẵn mẫu tin nhắn chốt lịch và cách tính sức chứa mùa cao điểm.

#xaykenh #chotlich #muatet #tiemnail #tiemtoc

### 10. Khách đang tìm tiệm trên social như tìm trên Google

Tối ưu TikTok để khách tìm thấy tiệm: mỗi video 1 từ khóa, xuất hiện trong lời nói, chữ trên video và câu đầu caption. Thêm 4 việc ngoài slide:

1. Giữ 1 từ khóa cho một chuỗi 3 đến 5 video liên tiếp, để kênh được hiểu là chuyên về dịch vụ đó.
2. Gắn vị trí tiệm vào mọi video, video sẽ nằm trong trang địa điểm của tiệm.
3. Xem nguồn lượt xem trong phần số liệu của từng video. Phần "Tìm kiếm" tăng dần là từ khóa đang chạy.
4. Cập nhật hồ sơ tiệm trên Google Maps: giờ mở cửa, số điện thoại, ảnh mới. Khách xem video xong thường mở Maps để tìm đường.

Thử ngay: gõ "dịch vụ + khu vực" của tiệm mình vào TikTok, xem ai đang xuất hiện.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, có sẵn bảng để lập 10 từ khóa cho tiệm.

#xaykenh #seotiktok #tukhoa #tiemnail #tiemnho

### 11. 5 lời khuyên sai khi xây kênh cho tiệm nhỏ

Tiệm nhỏ cần khách quanh tiệm, không cần triệu view. Vậy thay cho 5 lời khuyên trên slide, nên làm gì:

1. Đăng 3 bài mỗi tuần, đều đặn và có chất lượng, thay vì đăng mỗi ngày rồi bỏ giữa chừng.
2. Chia nội dung theo tỷ lệ gợi ý: tay nghề 30%, kiến thức 30%, hậu trường 15%, mời mua 25%.
3. Cuối mỗi video có 1 lời mời cụ thể: nhắn tin, đặt lịch, ghé tiệm. Chia sẻ giá trị và mời mua không loại trừ nhau.
4. Đo bằng số tin nhắn hỏi dịch vụ mỗi tuần và số khách mới từ kênh, thay cho số follow.

Các bạn đồng ý hay không đồng ý điểm nào? Tranh luận với tui ở phần bình luận nhé.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh chi tiết, từ chọn ngách, lên nội dung đến ra đơn.

#xaykenh #chutiem #kinhdoanhnho #marketingtiemnho #tiemnho

### 12. Có nên chạy quảng cáo cho tiệm nhỏ?

Quảng cáo không tạo ra khách, nó chỉ đưa video đến nhiều người hơn. Trước khi bấm nút, tính 3 con số này:

1. Trần chi cho 1 khách mới = số nhỏ hơn giữa "lãi 1 lần làm" và "30% lãi 1 khách mang lại cả năm". Ví dụ lãi 100.000đ mỗi lần, khách đến 4 lần/năm thì trần là 100.000đ.
2. Ngân sách chạy thử = chi phí 1 tin nhắn × 20 đến 30 tin nhắn, chia đều 5 đến 7 ngày.
3. Chi phí 1 khách thật = tổng tiền chi ÷ số khách đến tiệm. Dưới trần thì tăng ngân sách từ từ, vượt trần thì dừng và xem lại video hoặc khâu tin nhắn.

Thêm 2 lưu ý: đừng sửa quảng cáo liên tục vài ngày đầu vì hệ thống cần thời gian tìm đúng người; dùng mã ưu đãi riêng cho khách từ quảng cáo để đếm cho đúng.

Comment "KÊNH", tui gửi các bạn bộ tài liệu xây kênh kèm bảng tính chi phí chạy quảng cáo, điền số là biết nên tăng, giữ hay dừng.

#xaykenh #chayquangcao #quangcaotiktok #quangcaofacebook #tiemnho

