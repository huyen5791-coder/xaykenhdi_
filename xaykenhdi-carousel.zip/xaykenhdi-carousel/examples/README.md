# 12 bài đã làm

- `finished/`: ảnh ghép tất cả slide của từng bài, để xem phong cách.
- `slides_text_12_bai.txt`: toàn bộ chữ trên slide của 12 bài (dùng làm mẫu giọng văn và cấu trúc).
- `captions/`: caption 3 bản (ngắn, kể chuyện, kiến thức) cho 12 bài.
- `manifest_12_bai.json`: tên bài, từ khóa CTA, caption theo từng bài.

Bài 1 đến 3 là phong cách đời đầu (có emoji, CTA "follow"); từ bài 4 trở đi mới đúng phong cách hiện tại. Bìa chuẩn nhất: bài 9 đến 12.
Chỉ bài 12 có `post.json` đầy đủ (`posts/12-co-nen-chay-quang-cao/`). Cần làm lại bài cũ thì nhờ Claude chuyển chữ từ `slides_text_12_bai.txt` sang post.json.
